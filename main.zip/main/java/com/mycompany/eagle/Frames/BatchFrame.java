
package com.mycompany.eagle.Frames;

import com.mycompany.eagle.Entities.Result;
import com.mycompany.eagle.Utilities.FirebaseCaller;
import com.mycompany.eagle.Utilities.UrlManager;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;
import net.thegreshams.firebase4j.error.FirebaseException;

public class BatchFrame extends javax.swing.JFrame {
    private String course;
    private ArrayList<ArrayList<Result>> batches; 

    public BatchFrame() {
        initComponents();
    }
    
    public BatchFrame(String course) throws FirebaseException, UnsupportedEncodingException {
        initComponents();
        this.course = course;
        lb_batch_course.setText("Course: " + course);
        
        this.batches = new FirebaseCaller(new UrlManager()
                .setCourseBatch(course)).getBatchResults();
        loadBatches(batches);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pn_lp_batch = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tb_batch_list = new javax.swing.JTable();
        btn_review_search3 = new javax.swing.JPanel();
        lb_batch_course = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        pn_lp_batch.setBackground(new java.awt.Color(51, 51, 51));
        pn_lp_batch.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel24.setFont(new java.awt.Font("Roboto", 1, 24)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel24.setText("BATCH RESULTS");
        pn_lp_batch.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 530, -1));

        tb_batch_list.setBackground(new java.awt.Color(102, 102, 102));
        tb_batch_list.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        tb_batch_list.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Batch", "Score", "Percentage"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane3.setViewportView(tb_batch_list);

        pn_lp_batch.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 80, 540, 299));

        btn_review_search3.setBackground(new java.awt.Color(51, 51, 51));
        btn_review_search3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lb_batch_course.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        lb_batch_course.setForeground(new java.awt.Color(255, 255, 255));
        lb_batch_course.setText("Course: ");
        btn_review_search3.add(lb_batch_course, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 360, 30));

        pn_lp_batch.add(btn_review_search3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 560, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pn_lp_batch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(pn_lp_batch, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BatchFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BatchFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BatchFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BatchFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BatchFrame().setVisible(true);
            }
        });
    }
    
    private DefaultTableModel setBatchTable() {
        DefaultTableModel model = new DefaultTableModel(0, 0);
        String header[] = new String[]{"BATCH", "SCORE",
            "PERCENTAGE"};
        model.setColumnIdentifiers(header);
        tb_batch_list.setModel(model);
        return model;
    }
    
    private void loadBatches(ArrayList<ArrayList<Result>> batches) {
        DefaultTableModel model = setBatchTable();
        int rowCount = 1;
        
        for (ArrayList<Result> batch : batches){
            
            int batch_corrects = 0;
            int reviewees = 0;
            for (Result result : batch){
                reviewees++;
                batch_corrects = batch_corrects + 
                        result.getBat_corrects();            
            }
            
            //displays as a row 
            Vector<Object> data = new Vector<Object>();
            data.add(rowCount);
            data.add(batch_corrects + "/" + (reviewees * 1000));
            double total_scores = reviewees * 1000;
            data.add((batch_corrects * 100) / total_scores + "%");
            
            
//            int total_scores = reviewees * 1000;
//            int counter = 0;
//            
//            while (total_scores > batch_corrects){
//                total_scores = total_scores - batch_corrects;
//                counter++;
//            }
//            
//            data.add(100/counter + "%");
            rowCount++;
            
            model.addRow(data);
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel btn_review_search3;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel lb_batch_course;
    private javax.swing.JPanel pn_lp_batch;
    private javax.swing.JTable tb_batch_list;
    // End of variables declaration//GEN-END:variables

    
}
